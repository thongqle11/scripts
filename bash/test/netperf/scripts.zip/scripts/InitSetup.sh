#!/bin/bash
# setup test machines 
RemoteIP=172.29.40.166`


echo Loading Driver
rmmod qede
rmmod qed
modprobe qed
modprobe -f qede
service iptables stop
/usr/local/src/netperf-2.6.0/src/netserver
service irqbalance stop
sleep 2
ifconfig eth5 192.168.1.166
ifconfig eth6 192.168.2.166
./SetTcpBuffers.sh
 
./multy_rss-affin.sh eth5-fp eth6-fp


ssh $RemoteIP 'rmmod qede; rmmod qed; modprobe qed; modprobe -f qede'
ssh $RemoteIP 'service iptables stop'
ssh $RemoteIP '/usr/local/src/netperf-2.6.0/src/netserver'
ssh $RemoteIP 'service irqbalance stop; sleep 2'
ssh $RemoteIP 'ifconfig eth5 192.168.1.166; ifconfig eth6 192.168.2.166'
ssh $RemoteIP '/usr/local/src/scripts/multy_rss-affin.sh eth4-fp eth5-fp'
ssh $RemoteIP '/usr/local/src/scripts/SetTcpBuffers.sh'

# test Conectivity
PingCount=$(ping -c 1 192.168.1.166 | grep 'received' | awk -F',' '{ print $2 }' | awk '{ print $1 }')
if [ $PingCount -eq 0 ]; then
  # 100% failed
echo "Conetivity test faild on port 0!!";
exit 1;
fi

PingCount=$(ping -c 1 192.168.2.166 | grep 'received' | awk -F',' '{ print $2 }' | awk '{ print $1 }')
if [ $PingCount -eq 0 ]; then
  # 100% failed
echo "Conetivity test faild on port 1!!"
exit 1
fi

echo Setup Done


