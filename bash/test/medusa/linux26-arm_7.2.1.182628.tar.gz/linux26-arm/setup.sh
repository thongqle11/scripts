#!/bin/sh

################################################################################
## Copyright (C) 2004, 2007 Finisar Coporation.  All rights reserved.
##
## =============================================================================
## Installation script for Medusa Labst Test Tools.
################################################################################

################################################################################
## Helpers.
################################################################################

## Try to use the standard system tools.

get_tool()
{
	for _dir in /sbin /usr/sbin /bin /usr/bin; do
		_file="${_dir}/${1}"
		if [ -f "${_file}" -a -x "${_file}" ]; then
			echo "${_file}"
			return 0
		fi
	done
	echo "${1}"
}

_tr=`get_tool tr`
_cut=`get_tool cut`

## Given an argument in "key=value" format, extract the key.

key_of()
{
	echo "${1}" | ${_cut} -d= -f1
}

## Given an argument in "key=value" format, extract the value.

value_of()
{
	echo "${1}" | ${_cut} -d= -f2-
}

################################################################################
## Parse the command line to see if we're running interactively or not.
################################################################################

_setup_dir=

_s=
_p=
_d=
_l=
_c=
_w=

_silent=
_slient_p=
_slient_d=
_silent_l=
_silent_c=
_silent_w=

while [ $# -ne 0 ]; do
	case "${1}" in
	"-s")
		_s="yup"
		;;
	"-p")
		_p="yup"
		;;
	"-d")
		if [ $# -gt 1 ]; then
			shift
			_d="${1}"
		fi
		;;
	"-l")
		if [ $# -gt 1 ]; then
			shift
			_l="${1}"
		fi
		;;
	"-c")
		if [ $# -gt 1 ]; then
			shift
			_c="${1}"
		fi
		;;
	"-w")
		if [ $# -gt 1 ]; then
			shift
			_w="${1}"
		fi
		;;
	--setup-dir=*)
		_setup_dir=`value_of "${1}"` 
		;;
	--silent=*)
		_silent=`value_of "${1}"`
		;;
	--silent-preserve=*)
		_silent_p=`value_of "${1}"`
		;;
	--silent-dir=*)
		_silent_d=`value_of "${1}"`
		;;
	--silent-lm=*)
		_silent_l=`value_of "${1}"`
		;;
	--silent-lm-days=*)
		_silent_c=`value_of "${1}"`
		;;
	--silent-lm-which=*)
		_silent_w=`value_of "${1}"`
		;;
	*)
		;;
	esac
	shift
done

################################################################################
## Let's try to run in an untainted root user environment.
################################################################################

_su=`get_tool su`

if [ "${_setup_dir}" = "" ]; then
	_setup=/tmp/setup.boot.sh
	_cwd=`pwd`
	cat > "${_setup}" << EOT
#!/bin/sh
"${_cwd}/setup.sh" \
	--setup-dir="${_cwd}" \
	--silent="${_s}" \
	--silent-preserve="${_p}" \
	--silent-dir="${_d}" \
	--silent-lm="${_l}" \
	--silent-lm-days="${_c}" \
	--silent-lm-which="${_w}"
EOT
	chmod 755 "${_setup}"

	echo
	echo "This program must run as root."
	echo "Please enter the root password if prompted."

##	"${_su}" - root -c "`pwd`/setup.sh" '\
##		--setup-dir="`pwd`" \
##		--silent="${_s}" \
##		--silent-preserve="${_s}" \
##		--silent-dir="${_d}" \
##		--silent-lm="${_l}" \
##		--silent-lm-days="${_c}" \

	"${_su}" - root -c "${_setup}"

	exit $?
fi

################################################################################
## If we're here, then we were su exec'ed.
################################################################################

_tput=`get_tool tput`

_cls="${_tput} clear"
_bb="`${_tput} bold`"
_be="`${_tput} rmso`"
_rb="`${_tput} rev`"
_re="`${_tput} rmso`"

## Make sure we are running inside the package directory.

cd "${_setup_dir}"

_booboo=

if [ ! -f "setup.sh" ]; then
	echo "ERR: cannot find 'setup.sh' in current directory"
	_booboo="yup"
fi

if [ ! -f "package.tar" ]; then
	echo "ERR: cannot find 'package.tar' in current directory"
	_booboo="yup"
fi

if [ ! -f "mltt.manifest" ]; then
	echo "ERR: cannot find 'mltt.manifest' in current directory"
	_booboo="yup"
fi

if [ ! -f "license.txt" ]; then
	echo "ERR: cannot find the end-user license agreement file in current directory"
	_booboo="yup"
fi

if [ "${_booboo}" = "yup" ]; then
	echo "ERR: cannot locate required files in the current directory"
	echo "ERR: this program must run from the package directory"
	echo
	exit 1
fi

## Source the manifest file.

. ./mltt.manifest

_gcc_libs=

################################################################################
## Target platform.
################################################################################

_target_arch_list="\
	linux-ia32 \
	linux26-ia32 \
	linux26-x64 \
	linux26-ia64 \
	linux26-powerpc \
	linux26-powerpc64 \
	linux26-arm \
	linux26-arm64 \
	solaris-sparc32 \
	solaris-sparc64 \
	solaris-ia32 \
	solaris10-ia32 \
	solaris10-x64 \
	hpux-ia64 \
	freebsd10-x64"

_uname=`get_tool uname`

_uname_r=`${_uname} -r`
_uname_s=`${_uname} -s | ${_tr} '[:upper:]' '[:lower:]'`

if [ "${_uname_s}" != "hp-ux" ]; then
	_uname_p=`${_uname} -p | ${_tr} '[:upper:]' '[:lower:]'`
fi

_uname_m=`${_uname} -m | ${_tr} '[:upper:]' '[:lower:]'`

_target_os=
_target_cpu=

if [ "${_uname_s}" = "linux" ]; then
	case "${_uname_r}" in
	2.4.*)
		_target_os="linux"
		;;
	*)
		_target_os="linux26"
		;;
	esac
elif [ "${_uname_s}" = "sunos" ]; then
	if [ "${_uname_p}" = "sparc" ]; then
		_target_os="solaris"
	else
		case "${_uname_r}" in
		5.1*)
			_target_os="solaris10"
			;;
		*)
			_target_os="solaris"
			;;
		esac
	fi
elif [ "${_uname_s}" = "freebsd" ]; then
	_target_os="freebsd"`echo "${_uname_r}" | ${_cut} -d. -f1`
elif [ "${_uname_s}" = "hp-ux" ]; then
	_target_os="hpux"
fi

case "${_target_os}" in
solaris*)
	_bits=`isainfo -b`
	if [ "${_uname_p}" = "sparc" ]; then
		_target_cpu="${_uname_p}${_bits}"
	else
		if [ "${_bits}" = "32" ]; then
			_target_cpu="ia32"
		else
			_target_cpu="x64"
		fi
	fi
	;;
linux*)
	case "${_uname_m}" in
	i*86)
		_target_cpu="ia32"
		;;
	x86_64)
		_target_cpu="x64"
		;;
	ppc)
		_target_cpu="powerpc"
		;;
	ppc64)
		_target_cpu="powerpc64"
		;;
	arm*)
		_target_cpu="arm"
		;;
	aarch64)
		_target_cpu="arm64"
		;;
	*)
		_target_cpu="${_uname_m}"
		;;
	esac
	;;
hpux)
	_target_cpu="${_uname_m}"
	;;
freebsd*)
	if [ "${_uname_m}" = "amd64" ]; then
		_target_cpu="x64"
	fi
	;;
*)
	_target_cpu="${_uname_p}"
	;;
esac

_target_arch="${_target_os}-${_target_cpu}"
_target_arch32=
_target_safenet_arch=
_target_arch_bits=
_ld_library_path_name=
_no_slm=

_gcc_libs="${_libgcc} ${_libstdcxx}"
_mlmc_files="cutfile fixcrlf"

case "${_target_arch}" in
linux-ia32)
	_target_arch32="linux-ia32"
	_target_safenet_arch="linux-ia32"
	_target_arch_bits=32
	_ld_library_path_name=LD_LIBRARY_PATH
	;;
linux26-ia32)
	_target_arch32="linux26-ia32"
	_target_safenet_arch="linux-ia32"
	_target_arch_bits=32
	_ld_library_path_name=LD_LIBRARY_PATH
	;;
linux26-x64)
	_target_arch32="linux26-ia32"
	_target_safenet_arch="linux-ia32"
	_target_arch_bits=64
	_ld_library_path_name=LD_LIBRARY_PATH
	;;
linux26-ia64)
	_target_arch32=
	_target_safenet_arch=
	_target_arch_bits=64
	_ld_library_path_name=LD_LIBRARY_PATH
	_gcc_libs="${_gcc_libs} ${_libunwind}"
	_no_slm=yup
	;;
linux26-powerpc)
	_target_arch32=
	_target_safenet_arch=
	_target_arch_bits=32
	_ld_library_path_name=LD_LIBRARY_PATH
	_no_slm=yup
	;;
linux26-powerpc64)
	_target_arch32=
	_target_safenet_arch=
	_target_arch_bits=64
	_ld_library_path_name=LD_LIBRARY_PATH
	_no_slm=yup
	;;
linux26-arm)
	_target_arch32=
	_target_safenet_arch=
	_target_arch_bits=32
	_ld_library_path_name=LD_LIBRARY_PATH
	_no_slm=yup
	;;
linux26-arm64)
	_target_arch32=
	_target_safenet_arch=
	_target_arch_bits=64
	_ld_library_path_name=LD_LIBRARY_PATH
	_no_slm=yup
	;;
solaris-sparc32)
	_target_arch32="solaris-sparc32"
	_target_safenet_arch="solaris-sparc32"
	_target_arch_bits=32
	_ld_library_path_name=LD_LIBRARY_PATH
	;;
solaris-sparc64)
	_target_arch32="solaris-sparc32"
	_target_safenet_arch="solaris-sparc32"
	_target_arch_bits=64
	_ld_library_path_name=LD_LIBRARY_PATH
	;;
solaris-ia32)
	_target_arch32=
	_target_safenet_arch=
	_target_arch_bits=32
	_ld_library_path_name=LD_LIBRARY_PATH
	_no_slm=yup
	;;
solaris10-ia32)
	_target_arch32=
	_target_safenet_arch=
	_target_arch_bits=32
	_ld_library_path_name=LD_LIBRARY_PATH
	_no_slm=yup
	;;
solaris10-x64)
	_target_arch32=
	_target_safenet_arch=
	_target_arch_bits=64
	_ld_library_path_name=LD_LIBRARY_PATH
	_no_slm=yup
	;;
hpux-ia64)
	_target_arch32=
	_target_safenet_arch=
	_target_arch_bits=64
	_ld_library_path_name=LD_LIBRARY_PATH
	_no_slm=yup
	;;
freebsd10-x64)
	_target_arch32=
	_target_safenet_arch=
	_target_arch_bits=64
	_ld_library_path_name=LD_LIBRARY_PATH
	_no_slm=yup
	;;
darwin-powerpc)
	echo "INFO: will only run through the setup script for debugging"
	echo
	;;
*)
	echo "ERR: ${_target_arch} is not supported"
	echo
	exit 1
	;;
esac

_prompt=`get_tool echo`
_c=

case "${_target_os}" in
linux*|freebsd*)
	_prompt="/bin/echo -n"
	;;
solaris*)
	if [ -f "/usr/ucb/echo" ]; then
		_prompt="/usr/ucb/echo -n"
	fi
	;;
hpux)
	_c="\\c"
	;;
*)
	;;
esac

################################################################################
## Installation globals.
################################################################################

_install_dir="/opt/medusa_labs"
_lm_server=
_lm_port=
_slm_server="<unset>"
_slm_port=5093
_mlm_server="<unset>"
_mlm_port=5033
_lm_days=5
_lm_provider=medusa
_x_cmd=
_x_cmd_args=

_tools_dir=

_old_config=

_chkconfig=`get_tool chkconfig`
if [ "${_chkconfig}" = "chkconfig" ]; then
	_chkconfig=
fi

_insserv=`get_tool insserv`
if [ "${_insserv}" = "insserv" ]; then
	_insserv=
fi

_service=`get_tool service`
if [ "${_service}" = "service" ]; then
	_service=
fi

_systemctl=`get_tool systemctl`
if [ "${_systemctl}" = "systemctl" ]; then
	_systemctl=
fi

_update_rc_d=`get_tool update-rc.d`
if [ "${_update_rc_d}" = "update-rc.d" ]; then
	_update_rc_d=
fi

parse_config()
{
	_install_dir=`cd "${MEDUSA_MLTT_INSTALL_DIR}/.." && pwd`

	while : ; do
		read _line
		if [ $? -ne 0 ]; then
			return 0
		fi
		if [ "${_line}" = "" ]; then
			continue
		fi

		_key=`key_of ${_line}`
		_value=`value_of ${_line} | cut -d ';' -f1`

		case "${_key}" in
		"SERVER")
			_slm_server="${_value}"
			;;
		"PORT")
			_slm_port="${_value}"
			;;
		"MLM_SERVER")
			_mlm_server="${_value}"
			;;
		"MLM_PORT")
			_mlm_port="${_value}"
			;;
		"DEFAULT_CHECKOUT")
			_lm_days="${_value}"
			;;
		"EXTERNAL_CMD")
			_x_cmd="${_value}"
			;;
		"EXTERNAL_ARGS")
			_x_cmd_args="${_value}"
			;;
		esac
	done
}

parse_shed_env()
{
	while : ; do
		read _line
		if [ $? -ne 0 ]; then
			return 0
		fi
		if [ "${_line}" = "" ]; then
			continue;
		fi

		_key=`key_of ${_line}`
		_value=`value_of ${_line} | cut -d ';' -f1`

		if [ "${_key}" = "lm.provider" ]; then
			_lm_provider=${_value}
			_lm_provider=medusa
		fi
	done	
}

if [ "${MEDUSA_MLTT_INSTALL_DIR}" != "" -a -d "${MEDUSA_MLTT_INSTALL_DIR}" ]; then
	if [ -f "${MEDUSA_MLTT_INSTALL_DIR}/config/MedusaTools.cfg" ]; then
		parse_config < "${MEDUSA_MLTT_INSTALL_DIR}/config/MedusaTools.cfg"
		_old_config="yup"
	fi
	if [ -f "${MEDUSA_MLTT_INSTALL_DIR}/bin/medusa.shed.env" ]; then
		"${MEDUSA_MLTT_INSTALL_DIR}/bin/medusa.shed.env" > /tmp/.medusa.shed.env
		parse_shed_env < /tmp/.medusa.shed.env
	fi
	if [ "${_lm_provider}" = "" ]; then
		_lm_provider=safenet
	fi
else
	_lm_provider=medusa
fi

if [ "${_no_slm}" = "yup" ]; then
	_lm_provider=medusa
fi

_lm_provider=medusa

set_lm_from_provider()
{
	if [ "${_lm_provider}" = "medusa" ]; then
		_lm_server=${_mlm_server}
		_lm_port=${_mlm_port}
	else
		_lm_server=${_slm_server}
		_lm_port=${_slm_port}
	fi
}

set_lm_from_provider

_etc_init=
_etc_rc3=
_etc_rc5=
_etc_systemd=

case "${_target_os}" in
linux*)
	if [ -d "/etc/init.d" -a ! -h "/etc/init.d" ]; then
		_etc_init="/etc/init.d"
		_etc_rc3="/etc/init.d/rc3.d"
		_etc_rc5="/etc/init.d/rc5.d"
	elif [ -d "/etc/rc.d" -a -d "/etc/rc.d/init.d" ]; then
		_etc_init="/etc/rc.d/init.d"
		_etc_rc3="/etc/rc.d/rc3.d"
		_etc_rc5="/etc/rc.d/rc5.d"
	fi
	if [ -d "/etc/systemd/system" ]; then
		_etc_systemd="/etc/systemd/system"
	fi
	;;
solaris*)
	_etc_init="/etc/init.d"
	_etc_rc3="/etc/rc3.d"
	_etc_rc5="/etc/rc5.d"
	;;
hpux)
	_etc_init="/sbin/init.d"
	_etc_rc3="/sbin/rc3.d"
	_etc_rc5="/sbin/rc5.d"
	;;
freebsd*)
	_etc_init="/usr/local/etc/rc.d"
	_etc_rc3="/tmp/.cheese"
	_etc_rc5="/tmp/.cheese"
	;;
esac

if [ "${_etc_init}" = "" ]; then
	echo "ERR: unable to determine system initialization directory"
	echo
	exit 1
fi

################################################################################
## Intallation steps.
################################################################################

_st_welcome=0
_st_eula=1
_st_install_dir=2
_st_lm_info=3
_st_confirm=4
_st_install=5
_st_exit_success=6
_st_exit_failure=7
_st_exit_cancel=8

_st_current=${_st_welcome}

prompt()
{
	echo "${_bb}Please enter one of the following choices.${_be}"
	echo
	${_prompt} "${1}${_c}"
}

prompt2()
{
	${_prompt} "${1}${_c}"
}

st_welcome()
{
	${_cls}

	echo "${_rb}                                             ${_re}"
	echo "${_rb} Welcome to Medusa Labs Test Tools Installer ${_re}"
	echo "${_rb}                                             ${_re}"
	echo
	echo "\
This script will guide you to install and initially configure the Medusa Labs \
Test Tools on this computer."
	echo

	prompt "${_bb}(c)${_be} to continue or ${_bb}(x)${_be} to cancel and exit: "
	read _action

	case "${_action}" in
	"c")
		return ${_st_eula}
		;;
	"x")
		return ${_st_exit_cancel}
		;;
	esac

	return ${_st_welcome}
}

st_eula()
{
	${_cls}
	more license.txt

	echo
	prompt "\
${_bb}(c)${_be} accept the terms of the End User License Agreement and continue \
or ${_bb}(x)${_be} to decline and exit: "
	read _action

	case "${_action}" in
	"c")
		return ${_st_install_dir}
		;;
	"x")
		return ${_st_exit_cancel}
		;;
	esac

	return ${_st_eula}
}

st_install_dir()
{
	${_cls}

	echo "${_rb}                        ${_re}"
	echo "${_rb} Installation Directory ${_re}"
	echo "${_rb}                        ${_re}"

	echo "\
Please enter the installation directory.  It is currently set to the following \
directory:"
	echo
	echo "    ${_bb}${_install_dir}${_be}"
	echo
	echo "${_bb} NOTE: ${_be} this must be an absolute path."
	echo
	echo "\
The package will be installed in the ${_bb}\"test_tools\"${_be} subdirectory in \
the installation directory you choose."
	echo
	prompt2 "\
Type the desired installation directory and press ${_bb}RETURN${_be} or \
${_bb}ENTER${_be} to change the current setting, ${_bb}(c)${_be} to accept the \
current setting and continue, or ${_bb}(x)${_be} to cancel and exit: "
	read _action

	case "${_action}" in
	"c")
		return "${_st_lm_info}"
		;;
	"x")
		return ${_st_exit_cancel}
		;;
	*)
		_the_dir=`echo "${_action}" | cut -d/ -f2-`
		if [ "/${_the_dir}" = "${_action}" ]; then
			_install_dir="${_action}"
		else
			echo
			prompt2 "\
${_bb}\"${_action}\"${_be} is not an absolute path.  Press ${_bb}RETURN${_be} \
or ${_bb}ENTER${_be} to continue: "
			read _action
		fi
		;;
	esac

	return ${_st_install_dir}
}

old_st_lm_provider()
{
	if [ "${_no_slm}" = "yup" ]; then
		echo
		prompt2 "This system only supports Medusa License Manager. \
Press ${_bb}RETURN${_be} or ${_bb}ENTER${_be} \
to continue: "
		_lm_provider=medusa
		read _answer
	else
		echo
		prompt2 "Enter the license provider (1=medusa, 2=safenet): "
		read _answer
		if [ "${_answer}" = "1" ]; then
			_lm_provider=medusa
		elif [ "${_answer}" = "2" ]; then
			_lm_provider=safenet
		else
			echo
			prompt2 "Must enter '1' for Medusa License Manager or \
'2' for SafeNet License Manager.  Press ${_bb}RETURN${_be} \
or ${_bb}ENTER${_be} to continue: "
			read _answer
		fi
	fi
}

st_lm_provider()
{
	_lm_provider=medusa
}

st_lm_server()
{
	echo
	prompt2 "Enter the license server name or IP: "
	read _answer
	if [ "${_answer}" != "" ]; then
		_lm_server="${_answer}"
	fi
	if [ "${_lm_provider}" = "medusa" ]; then
		_mlm_server="${_lm_server}"
	else
		_slm_server="${_lm_server}"
	fi
}

st_lm_port()
{
	echo
	prompt2 "Enter the license server port: "
	read _answer
	if [ "${_answer}" != "" ]; then
		_lm_port="${_answer}"
	fi
	if [ "${_lm_provider}" = "medusa" ]; then
		_mlm_port="${_lm_port}"
	else
		_slm_port="${_lm_port}"
	fi
}

st_lm_days()
{
	echo
	prompt2 "Enter the default license check-out days: "
	read _answer
	if [ "${_answer}" != "" ]; then
		_lm_days="${_answer}"
	fi
}

st_lm_info()
{
	${_cls}

	echo "${_rb}                      ${_re}"
	echo "${_rb} License Manager Info ${_re}"
	echo "${_rb}                      ${_re}"
	echo
	echo "\
Enter the license server information for network license check-out/in \
operations. If your deployment uses proxy check-out or if this is a trial/demo \
installation, you may leave these fields as is and continue."
	echo
	echo "Current settings are: "
	echo
	echo "        Provider:               ${_bb}${_lm_provider}${_be}"
	echo
	echo "    (1) Server:                 ${_bb}${_lm_server}${_be}"
	echo "    (2) Port:                   ${_bb}${_lm_port}${_be}"
	echo "    (3) Default check-out days: ${_bb}${_lm_days}${_be}"
	echo

	if [ "${_no_slm}" = "yup" ]; then
		echo "${_bb}NOTE:${_be} this system only supports Medusa License Manager."
		echo
	fi
	prompt "\
${_bb}(1)${_be} to change the server name or IP address, ${_bb}(2)${_be} to \
change the port number, ${_bb}(3)${_be} to change to default license check-out \
days, ${_bb}(c)${_be} to accept the settings and continue, ${_bb}(p)${_be} to \
return to the previous step, or ${_bb}(x)${_be} to cancel and exit: "
	read _action

	case "${_action}" in
	"1")
		st_lm_server
		;;
	"2")
		st_lm_port
		;;
	"3")
		st_lm_days
		;;
	"c")
		return ${_st_confirm}
		;;
	"p")
		return ${_st_install_dir}
		;;
	"x")
		return ${_st_exit_cancel}
		;;
	esac

	return ${_st_lm_info}
}

st_confirm()
{
	${_cls}

	echo "${_rb}                               ${_re}"
	echo "${_rb} Confirm Installation Settings ${_re}"
	echo "${_rb}                               ${_re}"
	echo
	echo "\
Please review the following settings you have entered.  If you need to make \
changes, go back to the previous pages and make the necessary changes."
	echo
	echo "    Installation directory:    ${_bb}${_install_dir}${_be}"
	echo "    License manager provider:  ${_bb}${_lm_provider}${_be}"
	echo "    License manager server:    ${_bb}${_lm_server}${_be}"
	echo "    License manager port:      ${_bb}${_lm_port}${_be}"
	echo "    License default check-out: ${_bb}${_lm_days} days${_be}"
	echo

	prompt "\
${_bb}(c)${_be} to confirm the current settings and install the software, \
${_bb}(p)${_be} to return to the previous page to make changes, or \
${_bb}(x)${_be} to cancel and exit: "

	read _action

	case "${_action}" in
	"c")
		return ${_st_install}
		;;
	"p")
		return ${_st_lm_info}
		;;
	"x")
		return ${_st_exit_cancel}
		;;
	esac

	return ${_st_confirm}
}

st_install_stop_service()
{
	echo "Stopping service..."

	if [ -f "${_etc_init}/mlttpd" ]; then
		"${_etc_init}/mlttpd" stop
	fi

	if [ -f "${_etc_systemd}/maagent.service" ]; then
		if [ "${_systemctl}" != "" ]; then
			"${_systemctl}" stop maagent.service
		fi
	fi

	if [ -f "${_etc_init}/maagent" ]; then
		if [ "${_service}" != "" ]; then
			"${_service}" maagent stop
		else
			"${_etc_init}/maagent" stop
		fi
	fi

	sleep 5
	pkill -KILL maagent
}

st_install_start_service()
{
	echo "Starting service..."

	if [ "${_systemctl}" != "" ]; then
		"${_systemctl}" start maagent.service
	elif [ "${_service}" != "" ]; then
		"${_service}" maagent start
	else
		"${_etc_init}/maagent" start
		if [ "${_uname_s}" = "linux" ]; then
			echo "WARNING: setup was unable to determine the init process"
			echo "WARNING: the agent service many not start automatically"
			echo "         during the boot process"
		fi
	fi
}

do_setenv()
{
	_file=`cd && pwd`/${1}

	if [ ! -f "${_file}" -a ! -h "${_file}" ]; then
		cp /dev/null "${_file}"
	fi

	"${_tools_dir}/bin/medusa.shed.env" --strip-medusa-env "${_file}" \
		> "${_file}.new"

	if [ "${1}" = ".profile" -o "${1}" = ".bashrc" -o "${1}" = ".bash_profile" ]; then
		cat >> "${_file}.new" << EOT
## MEDUSA BEGIN ##
## Automatically generated - DO NOT edit between these comment lines.

if [ "\${MEDUSA_ENV:-''}" != "yup" ]; then
	MEDUSA_MLTT_INSTALL_DIR="${_tools_dir}/"
	export MEDUSA_MLTT_INSTALL_DIR
	PATH="\${MEDUSA_MLTT_INSTALL_DIR}bin:\${PATH}"
	export PATH
	MEDUSA_MLM_ADMIN_CFG="${_tools_dir}/config/MedusaTools.cfg"
	export MEDUSA_MLM_ADMIN_CFG
	MEDUSA_MLM_PRODUCT=1/1
	export MEDUSA_MLM_PRODUCT
	MEDUSA_ENV="yup"
	export MEDUSA_ENV
fi

type pain > /dev/null 2>&1
if [ \$? -ne 0 ]; then
	PATH="\${MEDUSA_MLTT_INSTALL_DIR}bin:\${PATH}"
fi

## MEDUSA END ##
EOT
	else
		cat >> "${_file}.new" << EOT
## MEDUSA_BEGIN ##
## Automatically generated - DO NOT edit between these comment lines.

if (! \$?MEDUSA_ENV) then
	setenv MEDUSA_MLTT_INSTALL_DIR "${_tools_dir}/"
	setenv MEDUSA_MLM_ADMIN_CFG "${_tools_dir}/config/MedusaTools.cfg"
	setenv MEDUSA_MLM_PRODUCT 1/1
	setenv PATH "\${MEDUSA_MLTT_INSTALL_DIR}bin:\${PATH}"
	setenv MEDUSA_ENV "yup"
endif
## MEDUSA_END ##
EOT
	fi

	chmod +w "${_file}"
	mv "${_file}.new" "${_file}"
}

do_install()
{
	echo

	st_install_stop_service

	_tools_dir="${_install_dir}/test_tools"

	if [ ! -d "${_tools_dir}" ]; then
		mkdir -p "${_tools_dir}"
	fi

	echo "Removing old binaries..."
	for _dir in bin ${_target_arch_list}; do
		if [ -d "${_tools_dir}/${_dir}" ]; then
			rm -rf "${_tools_dir}/${_dir}"
			if [ $? -ne 0 ]; then
				echo "ERR: failed to remove \"${_tools_dir}/${_dir}\""
				return ${_st_exit_failure}
			fi
		fi
	done

	echo "Installing executables..."

	_package="${_setup_dir}/package.tar"

	for _file in ${_bin}; do
		_bin_file="${_target_arch}/bin/${_file}"
		(
			echo "... ${_bin_file}"
			cd "${_tools_dir}" && tar xf "${_package}" "${_bin_file}"
		)
		if [ $? -ne 0 ]; then
		### TEMP ###
			echo
			##return ${_st_exit_failure}
		fi
	done

	if [ "${_target_arch32}" != "" ]; then
		for _file in ${_bin32}; do
			_bin_file="${_target_arch32}/bin/${_file}"
			(
				echo "... ${_bin_file}"
				cd "${_tools_dir}" && tar xf "${_package}" "${_bin_file}"
			)
			if [ $? -ne 0 ]; then
				return ${_st_exit_failure}
			fi
		done
	fi

	echo "Installing shared libraries..."

	for _file in ${_so}; do
		_bin_file="${_target_arch}/lib/libmedusa.${_file}.so"
		(
			echo "... ${_bin_file}"
			cd "${_tools_dir}" && tar xf "${_package}" "${_bin_file}"
		)
		if [ $? -ne 0 ]; then
		### TEMP ###
			echo
			##return ${_st_exit_failure}
		fi
	done

	if [ "${_target_arch32}" != "" ]; then
		if [ "${_target_arch}" != "${_target_arch32}" ]; then
			for _file in ${_so32}; do
				_bin_file="${_target_arch32}/lib/libmedusa.${_file}.so"
				(
					echo "... ${_bin_file}"
					cd "${_tools_dir}" && tar xf "${_package}" "${_bin_file}"
				)
				if [ $? -ne 0 ]; then
					return ${_st_exit_failure}
				fi
			done
		fi
	fi

	if [ "${_safenet_bin}" != "" ]; then
		echo "Installing license management client tools..."

		for _file in ${_safenet_bin}; do
			_bin_file="${_target_safenet_arch}/bin/${_file}"
			(
				echo "... ${_bin_file}"
				cd "${_tools_dir}" && tar xf "${_package}" "${_bin_file}"
			)
			if [ $? -ne 0 ]; then
				return ${_st_exit_failure}
			fi
		done

		_bin_file="${_target_safenet_arch}/lib/${_safenet_so}"
		(
			echo "... ${_bin_file}"
			cd "${_tools_dir}" && tar xf "${_package}" "${_bin_file}"
		)
		if [ $? -ne 0 ]; then
			return ${_st_exit_failure}
		fi
	fi

	if [ "${_gcc_version}" != "" ]; then
		echo "Installing GCC ${_gcc_version} runtime libraries..."

		for _file in ${_gcc_libs} cheese; do
			if [ "${_file}" = "cheese" ]; then
				break
			fi
			_bin_file="${_target_arch}/lib/${_file}"
			(
				echo "... ${_bin_file}"
				cd "${_tools_dir}" && tar xf "${_package}" "${_bin_file}"
			)
			if [ $? -ne 0 ]; then
				return ${_st_exit_failure}
			fi

			if [ "${_target_arch32}" != "" ]; then
				if [ "${_target_arch}" != "${_target_arch32}" ]; then
					_bin_file="${_target_arch32}/lib/${_file}"
					(
						echo "... ${_bin_file}"
						cd "${_tools_dir}" && tar xf "${_package}" "${_bin_file}"
					)
					if [ $? -ne 0 ]; then
						return ${_st_exit_failure}
					fi
				fi	
			fi
		done
	fi

	(
		cd "${_tools_dir}/${_target_arch}/lib"
		if [ -f "/sbin/ldconfig" ]; then
			/sbin/ldconfig -n . > /dev/null 2>&1
		else
			if [ "${_libstdcxx}" != "" ]; then
				_libstdcxx_link=libstdc++.so.${_libstdcxx_v}
				if [ "${_libstdcxx}" != "${_libstdcxx_link}" ]; then
					ln -s "${_libstdcxx}" "${_libstdcxx_link}"
				fi
			fi
		fi
	)

	if [ $? -ne 0 ]; then
	### TEMP ###
		echo
		##return ${_st_exit_failure}
	fi

	if [ "${_target_arch32}" != "" ]; then
		if [ "${_target_arch}" != "${_target_arch32}" ]; then
			(
				cd "${_tools_dir}/${_target_arch32}/lib"
				if [ -f "/sbin/ldconfig" ]; then
					/sbin/ldconfig -n . > /dev/null 2>&1
				else
					if [ "${_libstdcxx}" != "" ]; then
						ln -s ${_libstdcxx} libstdc++.so.${_libstdcxx_v}
					fi
				fi
			)
			if [ $? -ne 0 ]; then
				return ${_st_exit_failure}
			fi
		fi
	fi

	echo "Installing documentation..."

	if [ ! -d "${_tools_dir}/docs" ]; then
		mkdir -p "${_tools_dir}/docs"
		if [ $? -ne 0 ]; then
			return ${st_exit_failure}
		fi
	fi

	for _file in ${_docs}; do
		echo "... docs/${_file}"
		cp "${_setup_dir}/${_file}" "${_tools_dir}/docs"
		if [ $? -ne 0 ]; then
			return ${_st_exit_failure}
		fi
	done

	echo "Generating wrapper shell scripts..."

	if [ ! -d "${_tools_dir}/bin" ]; then
		mkdir -p "${_tools_dir}/bin"
	fi

	(
		cd "${_tools_dir}/bin"

		for _file in ${_bin}; do
			cat > "${_tools_dir}/bin/${_file}" << EOT
#!/bin/sh

##
## !!! Automatically generated !!!
##

MEDUSA_MLTT_INSTALL_DIR="${_tools_dir}/"
export MEDUSA_MLTT_INSTALL_DIR
MEDUSA_MLM_ADMIN_CFG="${_tools_dir}/config/MedusaTools.cfg"
export MEDUSA_MLM_ADMIN_CFG
MEDUSA_MLM_PRODUCT=1/1
export MEDUSA_MLM_PRODUCT

${_ld_library_path_name}="${_tools_dir}/${_target_arch}/lib:\$${_ld_library_path_name}"
export ${_ld_library_path_name}

PATH="\${MEDUSA_MLTT_INSTALL_DIR}bin:\${PATH}"
export PATH

exec "${_tools_dir}/${_target_arch}/bin/${_file}" "\$@"
EOT
		done

		if [ "${_target_arch32}" != "" ]; then
			for _file in ${_bin32}; do
				cat > "${_tools_dir}/bin/${_file}" << EOT
#!/bin/sh

##
## !!! Automatically generated !!!
##

MEDUSA_MLTT_INSTALL_DIR="${_tools_dir}/"
export MEDUSA_MLTT_INSTALL_DIR
MEDUSA_MLM_ADMIN_CFG="${_tools_dir}/config/MedusaTools.cfg"
export MEDUSA_MLM_ADMIN_CFG
MEDUSA_MLM_PRODUCT=1/1
export MEDUSA_MLM_PRODUCT

LD_LIBRARY_PATH="${_tools_dir}/${_target_arch32}/lib:${_tools_dir}/${_target_safenet_arch}/lib:\${LD_LIBRARY_PATH}"
export LD_LIBRARY_PATH

PATH="\${MEDUSA_MLTT_INSTALL_DIR}bin:\${PATH}"
export PATH

exec "${_tools_dir}/${_target_arch32}/bin/${_file}" "\$@"
EOT
			done

			for _file in ${_safenet_bin}; do
				cat > "${_tools_dir}/bin/${_file}" << EOT
#!/bin/sh

##
## !!! Automatically gnerated !!!
##

MEDUSA_MLTT_INSTALL_DIR="${_tools_dir}/"
export MEDUSA_MLTT_INSTALL_DIR
MEDUSA_MLM_ADMIN_CFG="${_tools_dir}/config/MedusaTools.cfg"
export MEDUSA_MLM_ADMIN_CFG
MEDUSA_MLM_PRODUCT=1/1
export MEDUSA_MLM_PRODUCT

LD_LIBRARY_PATH="${_tools_dir}/${_target_arch32}/lib:${_tools_dir}/${_target_safenet_arch}/lib:\${LD_LIBRARY_PATH}"
export LD_LIBRARY_PATH

PATH="\${MEDUSA_MLTT_INSTALL_DIR}bin:\${PATH}"
export PATH

exec "${_tools_dir}/${_target_safenet_arch}/bin/${_file}" "\$@"
EOT
			done
		fi
	)

	echo "Generating config file..."

	if [ ! -d "${_tools_dir}/config" ]; then
		mkdir -p "${_tools_dir}/config"
		if [ $? -ne 0 ]; then
			return ${_st_exit_failure}
		fi
	fi

	cat > "${_tools_dir}/config/MedusaTools.cfg" << EOT
SERVER=${_slm_server};
PORT=${_slm_port};
MLM_SERVER=${_mlm_server}
MLM_PORT=${_mlm_port}
DEFAULT_CHECKOUT=${_lm_days};
EXTERNAL_CMD=${_x_cmd};
EXTERNAL_ARGS=${_x_cmd_args};
ENABLE_DEPRECATED_IOCTLS=true
EOT

	echo "Installing service..."

	if [ "${_systemctl}" != "" ]; then
		"${_systemctl}" disable maagent.service > /dev/null 2>&1
	fi

	if [ "${_chkconfig}" != "" ]; then
		"${_chkconfig}" --del maagent > /dev/null 2>&1
	fi

	if [ "${_update_rc_d}" != "" ]; then
		"${_update_rc_d}" -f maagent remove > /dev/null 2>&1
	fi

	if [ -f "${_etc_init}/mlttpd" ]; then
		rm -f "${_etc_init}/mlttpd"
	fi

	if [ -f "${_etc_systemd}/maagent.service" ]; then
		rm -f "${_etc_systemd}/maagent.service"
	fi

	if [ -f "${_etc_init}/maagent" ]; then
		rm -f "${_etc_init}/maagent"
	fi

	if [ -d "${_etc_rc3}" ]; then
		(
			cd "${_etc_rc3}"
			rm -f _cheese_ *maagent
		)
	fi

	if [ -d "${_etc_rc5}" ]; then
		(
			cd "${_etc_rc5}"
			rm -f _cheese_ *maagent
		)
	fi

	if [ ! -d "${_etc_init}" ]; then
		mkdir -p "${_etc_init}"
	fi

	if [ "${_systemctl}" != "" -a "${_etc_systemd}" != "" ]; then
		cat > "${_etc_systemd}/maagent.service" << EOT
[Unit]
Description=Medusa A.R.I.E.S. Agent
After=network.target
Wants=SuSEfirewall2_setup.service
Wants=iptables.service
Wants=ip6tables.service

[Service]
Type=forking
ExecStart=${_tools_dir}/bin/maagent
PIDFile=/var/Medusa Labs/maagent.pid
KillSignal=SIGTERM
ControlGroup=cpu:/

[Install]
WantedBy=multi-user.target
EOT
	else
		if [ "${_insserv}" != "" ]; then
			cat > "${_etc_init}/maagent" << EOT
#!/bin/sh
### BEGIN INIT INFO
# Provides: maagent
# Required-Start: network
# Required-Stop: network
# Should-Start: 3 5
# Should-Stop: 0 1 2 6
# Default-Start: 3 5
# Default-Stop: 0 1 2 6
# Description: Medusa A.R.I.E.S. Agent
### END INIT INFO
EOT
		elif [ "${_chkconfig}" != "" ]; then
			cat > "${_etc_init}/maagent" << EOT
#!/bin/sh
# chkconfig: 35 99 1
# description: Medusa A.R.I.E.S. Agent
EOT
		elif [ "${_target_os}" = "freebsd10" ]; then
			cat > "${_etc_init}/maagent" << EOT
#!/bin/sh

# PROVIDE: maagent
# REQUIRE: DAEMON
# BEFORE: LOGIN
# KEYWORD: shutdown

. /etc/rc.subr

name="maagent"
start_cmd="\${name}_start"
stop_cmd="\${name}_stop"
rcvar=\${name}_enable

EOT
		fi

		cat >> "${_etc_init}/maagent" << EOT
##
## !!! Automatically generated !!!
##

MEDUSA_MLTT_INSTALL_DIR="${_tools_dir}/"
export MEDUSA_MLTT_INSTALL_DIR
MEDUSA_MLM_ADMIN_CFG="${_tools_dir}/config/MedusaTools.cfg"
export MEDUSA_MLM_ADMIN_CFG
MEDUSA_MLM_PRODUCT=1/1
export MEDUSA_MLM_PRODUCT

PATH="${_tools_dir}/bin:\${PATH}"
export PATH

EOT
		if [ "${_target_os}" = "freebsd10" ]; then
			cat >> "${_etc_init}/maagent" << EOT
maagent_start()
{
	echo "Starting Medusa A.R.I.E.S. Agent..."
	cd "${_tools_dir}"
	"${_tools_dir}/bin/maagent" > /dev/null 2>&1
	sleep 5
}

maagent_stop()
{
	echo "Stopping Medusa A.R.I.E.S. Agent..."
	pkill maagent > /dev/null 2>&1
	sleep 5
	pkill -KILL maagent > /dev/null 2>&1
}

load_rc_config \${name}
: \${maagent_enable:=YES}
run_rc_command "\$1"
EOT
			mkdir -p "/usr/local/etc/rc.conf.d" > /dev/null 2>&1
			echo "maagent_enable=\"YES\"" > /usr/local/etc/rc.conf.d/maagent

		else
			cat >> "${_etc_init}/maagent" << EOT
case \$1 in
start)
	echo "Starting Medusa A.R.I.E.S. Agent..."
	cd "${_tools_dir}"
	"${_tools_dir}/bin/maagent" > /dev/null 2>&1
	svcadm enable rstat > /dev/null 2>&1
	;;
stop)
	echo "Stopping Medusa A.R.I.E.S. Agent..."
	pkill maagent > /dev/null 2>&1
	sleep 5
	pkill -KILL maagent > /dev/null 2>&1
	;;
esac

sleep 5
EOT
		fi

		chmod 755 "${_etc_init}/maagent"
	fi

	if [ -f "${_etc_systemd}/maagent.service" ]; then
		"${_systemctl}" enable maagent.service > /dev/null 2>&1 
	elif [ "${_chkconfig}" != "" ]; then
		"${_chkconfig}" --add maagent > /dev/null 2>&1
		"${_chkconfig}" maagent on > /dev/null 2>&1
	elif [ "${_update_rc_d}" != "" ]; then
		"${_update_rc_d}" maagent defaults
	else
		if [ -d "${_etc_rc3}" ]; then
			(
				cd "${_etc_rc3}"
				ln -s "${_etc_init}/maagent" S99maagent
			)
		fi
		if [ -d "${_etc_rc5}" ]; then
			(
				cd "${_etc_rc5}"
				ln -s "${_etc_init}/maagent" S99maagent
			)
		fi
	fi

	echo "Setting permissions and owner..."

	if [ "${_target_os}" = "freebsd10" ]; then
		chown -R root:wheel "${_install_dir}"
	else
		chown -R root:root "${_install_dir}"
	fi

	chmod 755 "${_install_dir}"
	chmod 755 "${_tools_dir}"
	chmod 755 "${_tools_dir}/docs"
	chmod 755 "${_tools_dir}/config"
	chmod 644 "${_tools_dir}/config/MedusaTools.cfg"

	chmod -R 755 ${_tools_dir}/bin

	for _file in ${_docs}; do
		chmod 644 "${_tools_dir}/docs/${_file}"
	done

	for _dir in ${_target_arch_list}; do
		if [ -d "${_tools_dir}/${_dir}" ]; then
			chmod -R 755 "${_tools_dir}/${_dir}"
		fi
	done

	"${_tools_dir}/bin/medusa.shed.env" --lm-provider ${_lm_provider} > /dev/null 2>&1

	st_install_start_service

	echo "Setting up root user environment..."

	do_setenv .profile
	do_setenv .bashrc
	do_setenv .bash_profile
	do_setenv .cshrc
	do_setenv .tcshrc

	return ${_st_exit_success}
}

st_install()
{
	${_cls}

	echo "${_rb}               ${_re}"
	echo "${_rb} Installing... ${_re}"
	echo "${_rb}               ${_re}"

	do_install

	return $?
}

st_exit_success()
{
	echo
	echo "${_rb}                       ${_re}"
	echo "${_rb} Installation Complete ${_re}"
	echo "${_rb}                       ${_re}"
	echo
	echo "\
Please log out and log back in for the installation parameters to take effect."
	echo
}

st_exit_failure()
{
	echo
	echo "${_rb}                     ${_re}"
	echo "${_rb} Installation Failed ${_re}"
	echo "${_rb}                     ${_re}"
	echo
}

st_exit_cancel()
{
	${_cls}

	echo "${_rb}                        ${_re}"
	echo "${_rb} Installation Cancelled ${_re}"
	echo "${_rb}                        ${_re}"
	echo
}

install_silent()
{
	if [ "${_silent_p}" != "yup" ]; then
		if [ "${_silent_d}" != "" ]; then
			_dir=`echo "${_silent_d}" | cut -d/ -f2-`
			if [ "/${_dir}" != "${_silent_d}" ]; then
				echo "ERR: \"${_silent_d}\" is not absolute path"
				echo
				return 1
			fi
			_install_dir="${_silent_d}"
		fi

		if [ "${_silent_w}" != "" ]; then
			if [ "${_silent_w}" = "medusa" -o "${_silent_w}" = "safenet" ]; then
				_lm_provider="${_silent_w}"
			else
				echo "ERR: \"${_silent_w}\" is not a valid '-w' value"
				echo "ERR: Must be either \"medusa\" or \"safenet\""
				echo
				return 1
			fi
		fi

		_lm_provider=medusa

		if [ "${_silent_c}" != "" ]; then
			_lm_days="${_silent_c}"
		fi

		if [ "${_silent_l}" != "" ]; then
			_server=`echo "${_silent_l}" | cut -d: -f1`
			_port=`echo "${_silent_l}" | cut -d: -f2`

			if [ "${_server}" != "" ]; then
				_lm_server="${_server}"
			fi

			if [ "${_port}" != "" -a "${_port}" != "${_server}" ]; then
				_lm_port="${_port}"
			fi
		fi

		if [ "${_lm_provider}" = "safenet" ]; then
			if [ "${_lm_server}" != "" ]; then
				_slm_server="${_lm_server}"
			fi
			if [ "${_lm_port}" != "" ]; then
				_slm_port="${_lm_port}"
			fi
		elif [ "${_lm_provider}" = "medusa" ]; then
			if [ "${_lm_server}" != "" ]; then
				_mlm_server="${_lm_server}"
			fi
			if [ "${_lm_port}" != "" ]; then
				_mlm_port="${_mlm_port}"
			fi
		fi
	fi

	do_install

	if [ $? -eq ${_st_exit_success} ]; then
		return 0
	fi

	return 1
}

################################################################################
## Main:
################################################################################

## Non-interactive install.

if [ "${_silent}" = "yup" ]; then
	install_silent
	exit $?
fi

## Interactive install.

while : ; do
	case ${_st_current} in
	${_st_welcome})
		st_welcome
		_st_current=$?
		;;
	${_st_eula})
		st_eula
		_st_current=$?
		;;
	${_st_install_dir})
		st_install_dir
		_st_current=$?
		;;
	${_st_lm_info})
		st_lm_info
		_st_current=$?
		;;
	${_st_confirm})
		st_confirm
		_st_current=$?
		;;
	${_st_install})
		st_install
		_st_current=$?
		;;
	${_st_exit_success})
		st_exit_success
		exit 0
		;;
	${_st_exit_failure})
		st_exit_failure
		exit 1
		;;
	${_st_exit_cancel})
		st_exit_cancel
		exit 1
		;;
	*)
		echo "ERR: oops"
		exit 1
		;;
	esac
done

