Release notes:

Support contact: techsupport-medusa@viavisolutions.com

========================================================================
Medusa Labs Test Tools 7.2.0, February 17, 2016
========================================================================

-  Command Line Tools (pain, maim sock 3.6.1, catapult 2.0.1):
   + Added TCP coordinated burst mode to induce "TCP incast" - supports
     "stand-alone" coordination or multiple coordinator modes:
     see "sock -h -%T:"
   + Added the option to use ATA TRIM or SCSI UNMAP as pseudo write
     operation in regular I/O mode. This allows, for example, sending
     TRIM or UNMAP to random LBAs using the regular I/O option syntax.
     see "pain -h --scsi=5"
   + Added T10-PI support to format the target device with PI Type 0, 1,
     2, or 3, and issue READ/WRITE commands with appropriate T10-PI field
     values in data stream with PROTECT bits set in the CDBs. This includes
     adding READ/WRITE (32) for T10-PI Type 2 support:
     see "pain -h --secure-erase" for T10-PI enabled format options
     see "pain -h --scsi" for T10-PI enabled READ/WRITE command options.
   + Functionality and stability enhancements:
     - System ID clash mitigation for rare cases when system information
       fields are populated with improper, meaningless, or empty values.
     - Fix remote execution by host name to use a known IP address.
     - Fix catapult crash due to exit race condition in redundant monitor
       thread.
     - Switch from using standard C FILE stream to system call I/O to persist
       local license state and follow each write operation with file sync
       (i.e. "flush") system call to better avoid local state corruption
       resulting from frequent forced power-cycle due to OS crash or
       intentional test scenario.
     - Fix mixed r/w profile regression where 100% write specification resulted
       in a small amount of reads.
     - Minor license client check-out fix.
     - Updated "b:buffer_size" sampler banner output to use the actual
       buffer size or range used (e.g. if -% overrides -b.)
     - A fix for -m16 regression - restore the traditional next offset "hop"
       behavior.
     - Fix a crash resulting from bad target set iteration that can occur
       after pre-I/O initialization check.
     - -T now allows process-wide CPU affinity mask to be specified without
       binding each thread to a specific CPU. This can provide a significant
       IOPS performance improvement on NUMA systems.
     - Fixed tools crashing on some Linux guest OS (VMware VM).
     - Removed VMCI code that was causing some Linux guest OS kernel panic (VMWare VM).

-  GUI:
    + Added Medusa Sample Test Plans support.
    + Added custom graph options for X axis in Test Analysis Page.
    + Added SCSI UNMAP and ATA TRIM options for custom configuration.
    + Added new Format Unit options for Format and Secure Erase configuration.
    + Added Coordinated Burst Mode support in TCP App Simulation configuration.
    + Fixed "Configurations do not maintain order when copy and pasted".
    + Fixed "Steady State report has negative values when %Deviation is > 100".
    + Fixed "Target Hierarchy table coruption".
    + Fixed "GUI failed to exit after deleting history summaries".
    + Fixed "Retry failed I/O" setting in GUI needs to be able to accept "0" retries.

========================================================================
Medusa Labs Test Tools 7.1.0, July 20, 2015
========================================================================

-  Command Line Tools (pain, maim sock 3.5.1, catapult 2.0.1):
   + Linux AARCH64 support.
   + Compression/dedup testing support:
     see "pain -h -l -L -E -e" for new "-l80"
   + Journaled I/O and verification support: see "pain -h --journal"
   + Functional and stability enhancements:
     - Division-by-0 corner case crash running to target device with
       unusual logical block sizes (i.e not 512 bytes)
     - Increase latency histogram % output precision
     - Catapult on Windows correctly retrieves disk numbers even without
       running as elevated admin
     - Windows guest OS on ESXi 6 correctly locates the guest library
     - Catapult on Windows correctly retrieves long volume names without
       truncating them
     - Catapult file system enumeration output correctly matches the
       stats displayed in the GUI
     - Catapult on Linux no longer displays FUSE device as physical disk
     _ Catapult on Linux now supports discovery of FUSE file systems
     - "-l59" output corrected
     - "-l54" output corrected
     - System ID check is now more robust against abnormal variations
       seen on some systems that can change the ID each boot
     - Preliminary SMBIOS 3.0 compliance for host information
     - Mixed-mode .NET pattern preview function no longer leaking memory
     - Allow exclusion of a file system target using ".notarget" file
     - Prevent offset underflow into adjacent area during random access
       I/O when I/O area is not an exact multiple of user-specified
       alignment offset value
     - Bypass some /dev/mem access on Linux/ARM which caused crash rather
       than the expected I/O failure
     - Avoid I/O halt error-handling division-by-0
     - Do not crash when thread count is too high for given queue depth
       and buffer size
     - Corrections to I/O area calculation for full-device random access
     - Do not fail when Windows ::FlushFileBuffers() fails for -c to
       physical disk targets
     - Remove heap corruption from calling ::delete on memory allocated
       by vm::allocate()
     - Double check and account for offset underflow for sequential
       backward offset calculation when using seek-mixed I/O profile
     - Use correct OS-specific path separators for display and testing
       when running Windows-to-Unix or Unix-to-Windows remote testing
       using catapult -r in non-multitarget mode
     - Use the correct buffer size when only one -%r/w spec with "@<size>"
       per-spec buffer size is specified
     - Make sure max buffer size is inclusive if a buffer size range is
       specified for -%r/w spec.
     - Linux: O_SYNC is now disabled by default due to excessive flush
       commands sent to target when running to physical disks

-  GUI:
   + Added custom cpu affinity edit box for test plan and planning group.
   + Added The Enable Random Offset Alignment settings for I/O Type panel
     and Advance I/O Mix panel.
   + Added Compression and Deduplication setting panel for L80 pattern editor.
   + Added Journal tab for I/O journaling feature of Custom Configuration.
   + Fixed: Negative queue values for tables and graphs.
   + Fixed: GUI throws errors on launch if the system has the region set 
     to Germany and short date format is "dd-MMM-yy".
   + Fixed: Selecting "Specify Thread Start Delay" and/or
     "Specify Target Start Delay" in configurations results in repeated
     CLI specifications.
   + Fixed: "Cannot Find Path" Error when deleting History.
   + Fixed: "Advanced IO" - "Specify Custom I/O Mix" pull-up box for 
     "%Backward Sequential" can be increased even though "%Forward Sequential"
     is already at 100%.
   + Fixed: "Targets window-column on left needs to be locked to hostname". 
   + Fixed: GUI prompts to save changes when new configs are added and
     changes values if No is selected.
   + Fixed: Can use illegal characters in test plan name.
   + Fixed: "Override Default/Test Plan Offsets" no longer accepts the value of
     "0" at configuration level.
   + Fixed: Cursor focus jumps to different Test Plan in tree when enter key
     is pressed after changing plan or group name.
   + Fixed: "Stop" halts all tests in planning group running in parallel
     instead of just the selected one.
   + Fixed: Able to paste configs into "Medusa Sample Configurations" under
     the "Configurations" GUI.
   + Fixed: "Scramble Data" options under "Pattern Editor" are able to be
     completely deselected.

========================================================================
Medusa Labs Test Tools 7.0.0, Nov 19, 2014
========================================================================

-  Command Line Tools (pain, maim sock 3.4.0, catapult 2.0):
   + Target format options: see "pain -h --secure-erase"
     o ATA SECURITY ERASE
     o SCSI FORMAT UNIT
     o SCSI SANITIZE
   + TRIM/UNMAP support: see "pain -h --trim"
   + I/O latency histogram generation: see "pain -h --latency-histogram"
   + SMART attribute dump support: see "pain -h --smart"
   + SSS-PTS compliance steady-state detection support:
         see "pain -h --steady-state"
     o NOTE: Currently, for SSS-PTS compliance testing, a driver script
       for CLI or an equivalent GUI test plan must be created by the user.
       This feature provides a tool to allow SSS-PTS compliance testing
       easier by tracking the SSS-PTS defined measurement window and
       deviation values. Please contact "TechSupport-Medusa@jdsu.com"
       for assistance in developing such scripts.
   + Added 64-bit skip size support: see "pain -h --skip"
   + Added per-process thread pool option in maim: see "maim -h -t"
   + Fixed: Windows thread-cpu affinity setting to support up to 64 logical
     CPUs
   + Fixed: Windows catapult enumeration of more than 1024 devices
   + Fixed: trigger on I/O halt

-  GUI:
   + Added target erase and TRIM configurations
   + Added steady state input option
   + Added Test Plan exit on steady state feature
   + Added latency histogram input option
   + Added per-target latency histogram view
   + Added IOMETER ICF import feature
   + Added support to reconnect and resume remote tests after network
     interruption
   + Fixed: database synchronization issues causing exceptions
   + Fixed: GUI sometimes hangs during Test Plan imports
   + Fixed: exception when adding entries to TCP simulation options

========================================================================
Medusa Labs Test Tools 6.0.1, Dec 02, 2013
========================================================================

-  General
   + Linux VLAN support for network interface enumeration.
   + Solaris ZFS support.
   + Automatic and dynamic network firewall rule management.
   + Improved Linux multi-path device enumeration.
   + Catapult test execution in same console ("catapult --now").
   + Catapult support for Windows volumes without assigned drive letters.

-  Pain, Maim, Sock 3.3.3
   + UDP I/O support; see "sock -h -m31".
   + Throughput throttling; see "pain -h --cap".
   + Deferred sample collection; see "pain -h --sample-delay".
   + Extended device boundary checking; see "pain -h -O".
   + Pure performance mode; see "pain -h --perf-mode".
   + Enhanced NUMA support with localized I/O buffer allocation.
   + Windows IO Completion Port option; see "maim -h --win-iocp"
     (default is to use the APC, Asynchronous Procedure Call.)
   + Fixed Solaris partition size calculation.
   + Fixed I/O timeout monitor detection window.
   + Fixed "continue on error" --handler option.
   + Fixed full-device sequential I/O area calculation.
   + Fixed full-device random access overrun.
   + Fixed a memory leak when time stamp option is set.
   + Added a work-around for license check crash when running in a
     virtual machine with Linux guest OS.

-  GUI
   + Remote system license management.
   + Added test plan grouping.
   + vSphere ESX-to-guest VM topology display.
   + "Storage Command Line" and "Network Command Line" configurations.
   + Import/export test histories.
   + UDP I/O support.
   + Initial sample delay support.
   + Throughput limit support.
   + External application execution after test completion.
   + Pure performance mode support.
   + Multi-threaded asynchronous I/O support.
   + Cycle through read/write modes.
   + Target start delay support.
   + "Command Lines" tab expands multiple tests to CLI equivalents.

========================================================================
Medusa Labs Test Tools 6.0.0, Apr 04, 2012
========================================================================

-  General
   + Added Virtual Machine Licensing; see "User's Guide."
   + Improved the agent service resource utilization to enable larger
     deployments.
   + Added IPv6 interface discovery.
   + Added Windows support for multi-homed NICs.

-  Pain, Maim, Sock 3.3.1
   + Allow mixing full-device coverage with modes other than -m18
     (e.g. full-device maim -m16); see "pain -h --full-device".
   + True full-device sequential coverage to every addressable LBA
     with progress indication.
   + Sequential I/O block skip to prevent OS I/O coalescing; see
     "pain -h --skip".
   + Enable sock IPv6 network traffic generation; see "sock -h -f".
   + Target ramp-up delay; see "pain -h -S" for "-S" modification.
   + CLI parameters added to trigger data.
   + Maim uniform multi-threaded asynchronous I/O support with '-t'.
   + Trigger and/or stop testing on timeout or halt.
   + Enable test exit after first good retry; see "pain -h --handler"
     for the "x1" specification.
   + Linux device driver error detection from SG_IO in "--scsi" mode.
   + Support for Linux devices with block drivers but no SG_IO
     integration.

-  Critical fixes since 5.0.0
   + Fixed "pain -m17 --scsi" size error.
   + Fixed "-%o" false data corruption.
   + Fixed catapult no shutting down tests.
   + Fixed catapult -r to systems not in the same subnet.
   + Fixed catapult -v regression.
   + Fixed GUI hang when validating targets.
   + Fixed GUI reporting wrong devices sizes for Windows systems.

-  GUI
   + Added graphing to analysis.
   + Graphs can be exported as .csv files to allow re-creation of the
     graphs in a spreadsheet application.
   + Added support for IPv6 interfaces.

========================================================================
Medusa Labs Test Tools 5.0.0, May 6, 2011.
========================================================================

-   Pain, Maim, Sock 3.2.1
    + Added "pain --scsi" option to enable I/O by sending direct SCSI
      CDBs to target devices. See "pain -h --scsi" for more information.
      Use this option to:
      - Perform I/O to devices with sector sizes that are not supported
        by system I/O APIs (e.g. 520 bytes.)
      - See what SCSI check conditions are reported by target devices.
    + Added "sock -%T" transaction mode to simulate TCP/IP application
      loads (such as HTTP). See "sock -h -%T" for more information.
    + Added read-only and write-only supports to sock.

-   Catapult
    + Failure to list GUID table on Windows no longer results in a
      failure to list devices.
    + Exit grace period after a timed test is now configurable through
      the -y option.
    + Windows drives can now be brought online or taken offline using
      the --on and --off options.
    + Excluded devices can now be hidden from the output using -q.
    + Improved host filtering by IP address.

-   GUI
    + Added support for scsi passthrough options.
    + Advanced Read/Write profiles are now possible.
    + Added support for advanced I/O direction profiles.
    + GUI can now install tool upgrades to remote systems.
    + Support for non-512 byte sizes added as well as logical unit
      modifier for sizes.
    + Discovery of remote systems not in the current subnet now possible
      in the GUI.
    + Socket transaction mode configurations added.
    + GUI now maintains an active list of hosts online/offline states.
      - When new systems come online, they will automatically be added
      - When systems go offline, the GUI will recognize them as having
        done so after a short timeout period (typically 30 seconds).
    + Error handlers now supported.
    + Windows drives can now be brought online or taken offline via the
      targets browser.
    + External application triggering added.
    + Targets now have a properties dialog.
    + GUI can install remote checkout licenses.

========================================================================
Medusa Labs Test Tools 4.0.134, November 1, 2010
========================================================================

-   Added support for HP-UX on Itanium (hpux-ia64)

-   Maim
    + Fixed false data corruption with -m1 -B1 at -Q > 1.

-   Catapult
    + For remote inquiry and execution working directories, use the
      simple host name even if the user uses the fully qualified name.
      This restores 3.0 behavior for working directory names of tests
      launched by catapult.
    + Windows: fixed longish delay when querying device information.
    + Fixed -rlocalhost case.
    + Linux inquiry is more reliable

-   Pain, Maim, Catapult
    + Windows volume sizes now correctly identified.

-   GUI
    + Fixed running to remote Unix systems file system targets by using
      the mount point as the target directory rather than the device
      path.
    + Fixed bug with -%w100 and -%r100
    + Import of 3.0 configurations now keeps patterns and R/W values
    + Fixed issue where some history configurations would not be
      displayed when their results were available.

========================================================================
Medusa Labs Test Tools 4.0.119, July 15, 2010
========================================================================

Test Tools Updates

-   Support added for Linux Itanium, Solaris x86

-   Pain and Maim updated to 3.1.1.
    + Changed: switch to using Medusa License Management client -
      SafeNet is still supported.
    + Fixed: allow -X in -m17
    + Fixed: -x/-X output in .log (there was no space between "ON" and
      the offset value)
    + Fixed: first sample count of 0 no longer logs a false I/O halt.
    + Fixed: stroke size adjustment for -m18 can result in 0 file size,
      leading to floating point errors during initialization.
    + Fixed: Error count for read/write error was not being updated
    + Added: --reopen-on-retry option to open a new file descriptor
      before retrying a failed I/O
    + Fixed: pain/maim crash when EXTERNAL_CMD is specified but
      EXTERNAL_ARGS is not
    + Fixed: typo in license check message
    + Added: on-line help text for '-%s'
    + Fixed: crash if MEDUSA_MLTT_INSTALL_DIR is not set
    + Fixed: error event delineator ('=') output is now conditionalized
	  on trace level
    + Fixed: false data corruption using -l32 or -l33 with pre-scramble
      (-j1 or -j2)
    + Added: if -y is not specified for -l1, -l2, or -l4, make sure to
      use the I/O thread ID number as the pattern value
    + Fixed: work-around for SLES10/Itanium crash
    + Added: TCP I/O (-m30)
    + Fixed: trigger data is now appended to regular file targets
    + Added: -%o<size> to specify I/O offset alignment for random access
      I/O (-%f,b,x mix).

-   Sock 3.1.1 executable added to the suite.
    + Essentially like pain/maim with most of the same features but
      used for TCP/IP communication testing between multiple systems.
    + See "sock -h -f" for details on specifying remote echo servers.

-   GUI
    + Improved look and feel
    + Improved performance
    + GUI can now run to network targets
    + GUI uses less files and test logs are consolidated the same way
      they are in Catapult
    + Added remote license management

========================================================================
Medusa Labs Test Tools 3.0.158, June 12, 2009
========================================================================

Test Tools Updates

-   Pain and Maim updated to 3.0.1.
    + Uniform I/O mode support for all platforms (see pain -h -m)
    + Thread/CPU affinity setting (see pain -h -T)
    + Native Linux AIO support (concurrent multiple  I/O requests per
      I/O thread and vastly improved Maim I/O performance)
    + Full device coverage modes for UNIX (-m17 and -m18)
    + Random read/write percentage mix (see pain -h -%r -%w)
    + Sequential (forward, backward) /random access mix
      (see pain -h -%f -%b -%x)
    + Strict sequential continuous queuing I/O (maim -m1)
    + Auto detection of device or volume sector size (no longer
      restricted to 512B sector size assumption)
    + Exit grace period option (see pain -h --exit-grace-period)
    + New FC 8Gb jitter patterns (-l63 and -l64)
    + Ability to vary random data pattern sequence with different
      random seeds (see pain -h -y)
    + Ability to vary random read/write sequence and random-access
      sequence with different random seeds (see pain -h -%s)
    + Ability to specify offsets with granularity other than 1MB
      (see pain -h -x -X)
    + More flexible storage size and offset specification
      (see pain -h --file-size -x -X -b)
    + Improved '-l0' performance (pattern file is cached in memory
      if possible)
    + Multi-threaded Maim (EXPERIMENTAL! see maim -h -t)
      - KNOWN ISSUE: does not work with '-m16'
      - KNOWN ISSUE: does not work with '-m17'
    + Configurable trigger options for custom error handling
      (see pain -h --handler)
      - Ability to label error events as 'info', 'warning', 'error'
      - Set different retry counts for each error event
      - Set different trigger options for each error event (no trigger,
        regular trigger, external command, both)
      - Set different exit-on-error attributes for each error event
        (continue, continue until end of FOP, exit)
      - Set different exit scope for each error event (thread, program)
      - Set different trigger pattern for each error event

-   Catapult updated to 1.4.1.
    + Support Master Boot Records on Solaris for Solaris x86 v10
      GRUB bootloader
    + Support UFS filesystems on Solaris (no 'G' exclusion)
    + Support cciss HP RAID device on Linux
    + Set drive inaccessible 'Z' exclusion on Windows drives that are
      read-only to avoid starting tests on offline drives on
      Windows Server 2008
    + Exclude read-only filesystems (e.g., CDROM) on Linux as not
      accessible for filesystem access (see catapult -f)
    + Allow users to specify directories for test results
      (see catatapult -g)
    + Handle subdirectories better when copying logfiles from remote
      systems (see catapult -b)
    + Print the number of times tests successfully resumed if IO Halts
      are found when verifying logfiles (see catapult -vp and -vi)
    + Only print information about tests with errors when verifying
      logfiles (see catapult -vp and -vv)
    + Add new option to print information about all tests when
      verifying logfiles (see catapult -vvv)
    + Added current directory to search path for logfile verification
      (see catapult -vp)
    + Remove empty directories when cleaning up log files
      (see catapult -c)
    + Improved verification logfile contents (see catapult -vl)

-   Completely rewritten GUI
    + Adds remote management to the GUI
    + Improved workflow and layout
    + Ability to run multiple tests concurrently
    + Setup multiple tests to run from a single configuration
    + Configuration classes set up to help encourage specific types of
      testing
    + More comprehensive view of history of testing
    + Users can now type in their own command line to setup a
      configuration's settings
    + Test plans allow setting global parameters (I/O Timeout 
      monitoring, test run time, etc.)

-   Windows installer
    + Uses .NET 2.0 SP1 and Windows installer 3.1

========================================================================
Medusa Labs Test Tools 2.5, September 2007
========================================================================

Test Tools Updates
-   Pain and Maim updated 2.14.4.
-   Added support for additional platforms:
    + 64-bit Windows (native Itanium, AMD64, Intel EM64T).
    + 64-bit Linux (2.6.x kernel, native AMD64, Intel EM64T).
    + 64-bit Solaris (8 or above, native 64-bit SPARC).

Pain/Maim 2.14.4
-   Native 64-bit binaries.
-   "Large-file" support (> 4GB).
-   "O_DIRECT" support for Linux 2.6.x kernel.

Unix Installer
-   Identifies the OS version and installs the correct mix of binaries.
-   Non-interactive install mode added:

    e.g. ./setup.sh -s -d /opt/medusa_labs

    Command line options are:

    -s
        Install in non-interactive mode.  All other command line options
        are ignored unless -s is specified.

    -d "installation_directory"
        Installation root directory.  The Test Tools are installed in the
        "test_tools" sub-directory.

        If -d is not specified,

        1. If existing installation is detected, then the existing
           installation directory is used.
        2. Otherwise, the default "/opt/medusa_labs" is used.

    -l "license_server:port"
        License server name (or IP address) and port. ":port" is optional.

        If -l is not specified,

        1. If existing installation is detected, then the existing
           license server and port settings are used.
        2. Otherwise, the license server remains unset and default port
           port value of "5093" is used.

    -c <number>
        Default license check-out duration in number of days.

        If -c is not specified,

        1. If existing installation is detected, then the existing
           setting is used.
        2. Otherwise, default value of "5" is used.

    -p
        Preserve existing settings.  If -p is specified AND existing
        installation is detected, installer ignores -d, -l, and -c options
        (if specified) and uses the existing settings.

Windows Installer
-   Migrated to use Advanced Installer instead of InstallShield.
-   Created separate installations for 64-bit operating systems.
-   32-bit installer will no longer install on 64-bit operating systems.
-   Non-interactive install available:

    e.g Setup_x86.exe /qb MLTT_LM_SERVER=server MLTT_LM_PORT=5093

    Command line options are:

    /qb
        Install in non-interactive mode.  There may still be some interaction
        required to uninstall older versions of the tools.

    MLTT_LM_SERVER=<server>
        License server name (or IP address).  This MUST be provided or your
        configuration will point to server <unknown>.

    MLTT_LM_PORT=<port>
        Default is 5093, if you want a different port, you must specify one.

    MLTT_DEFAULT_CHECKOUT=<days>
        Default checkout is for 5 days.  If you wish to change this, you will
        need to supply a different number.

Catapult 1.3.5
-   Added 64-bit support.
-   Linux 2.6 inquiry now uses /dev/sd instead of raw because tools will open
    using O_DIRECT flag for non-cached access.
-   Solaris -l now uses meta devices instead of cached access.  More useful.
-   Improved usability of the -b option.
-   Bug fixes.

GUI
-   Added listing for patent numbers.
-   About and splash screens now display tool suite version.
-   Enabled drag/drop.
-   Test view no longer stuck to scrolling at bottom during tests.
-   Added 64-bit support and made options more consistent with command line
    tools.
-   License check out uses days defined in configuration.
-   Bug fixes.


========================================================================
Medusa Labs Test Tools 2.0, December 2006
========================================================================

Test Tools Updates
-   Pain and Maim updated to 2.14.3
-   Catapult updated to 1.3.3
-   Tools now have common suite version numbering.
-   New system abstraction layer implemented to facilitate future
    platform porting.
-   New internal communication protocol to enable remote test dispatching 
    and monitoring of Pain and Maim through Catapult.
-   Mlttproxy now incorporates server agent features to serve as the central
    process management point for each machine.

	
Pain/Maim 2.14.3
-	Added a 8b/10b neutral disparity "random" pattern with inversion (l62).
-	Fix for failure to write trigger on I/O halt error.
-	Improvement to -l0 (read data pattern from file) so that large pattern 
	files can be used and continually read.
-	New 8b/10b pattern (-l62).
-	Added -k switch, which allows user to change default byte ordering of 
	data patterns (on 4 byte word boundary.)
-	More detailed error logging for I/O timeout occurrences.
-	Added I/O completion statistics to performance log.
-	Added more test details to performance log.
-	New -q logging options.
-	Improved Windows event logging.
-	Fixed issue with performance counters showing incorrect values in 
	multi-target mode with high thread counts.
-	Fixed intermittent crash in Pain with high thread counts.
-	Fixed "NULL" file name appearing in log files on occassion.
-	Fixed problems with I/O retries not working sometimes in Maim.
-	Fixed bad data values displayed in .bad file with non-default comparison
	(-C modes.)
-	Fixed problem with Pain -m9 -w not working correctly.
-	Fixed triggering issue on I/O halts and timeouts.
-	Removed data comparison time from I/O timeout calculations.

Catapult 1.3.3
-	Remote test control.
-	Test verification mode improved.
-       New help layout.
-       Device enumeration now more informative.

GUI
-	Graphic performance gauges added.
-	Added ability to clear log files.
-	Keyboard shortcuts added to improve workflow.

========================================================================
Medusa Labs Test Tools Suite 1.2.3, November 1, 2005
========================================================================

Test Tools Updates
-	Pain and Maim updated to 2.14.2

Pain/Maim 2.14.2
-	Added data patterns from SATA specification (l54-59).
-	Added a 8b/10b neutral disparity "random" pattern (l60).
-	Added data pattern from SAS-2 specification (l61).
-	Added granular command line help.  -? or -h plus other switches
	will display help for only the indicated switches.
-	Added 0xCA value potential back into random pattern by request.
	The -l35 and -l60 patterns both have potential to cause a false
	analyzer trigger if set for the 0xCA value.  A warning message
	will be printed to the console.

Maim 2.14.2
-	Fixed problem with -B switch not working with -m16.

GUI 1.2
-	Default initial scripts are now installed as read-only
-	Read-only scripts are now uneditable
-	No longer freezes while waiting for a process to exit.
-	License check-in/out warnings and errors more appropriate.
-	Target selection no longer allows system/excluded drives to be
	selected.
-	If autosave is off, user is actually prompted before saving.


========================================================================
Medusa Labs Test Tools Suite 1.2.2, August 29, 2005
========================================================================

This is a maintenance release incorporating all known bug fixes since
the release of 1.2, including the fixes provided in Update 1 (hot fix
patch for select customers.)

- IMPORTANT UPDATE NOTE FOR WINDOWS VERSION

  The setup program is re-authored using InstallShield.  This addresses
  the issues noted below ("Notes regarding Windows setup program for
  1.2.")

  If you are upgrading from any previous version of the Test Tools,
  you still need to completely uninstall the existing version before
  before installing this or the newer version of the Test Tools.  Use
  the Windows "Add/Remove Programs" utility to uninstall the old version.

  For updates following installation of 1.2.2 or higher versions, simply
  choosing the "Repair" option in the setup program should work to
  successfully upgrade to a newer version.

  As before, choosing the same installation location as the previous
  version retains the old configuration settings as well as modifications
  made in the 1.2 GUI.

  The Medusa Labs Test Tools installer for Windows is not digitally signed.
  Your system may display a warning about this fact when running the
  installer.  As long as you have obtained the software through a trusted
  source (e.g. product CD-ROM from Finisar or through FTP to medusalabs.com,)
  you may ignore the warning and continue with installation.

Test Tools Updates
-	pain and maim updated to 2.14.1
-	catapult updated to 1.3.1

Pain/Maim 2.14.1
-	The -x/-X switches were modified to not use base offset.  This
	makes things a little more straight-forward when setting up
	tests with shared device access.
-	Fix for performance thread hanging sometimes after exit signal
	has been sent.
-	Removed occurrences of 0xCA pattern that would cause false analyzer
	triggers with -l35 variations.

Pain 2.14.1
-	Fixed bug in I/O trigger routine that could cause a false data
	corruption under certain circumstances.  An I/O halt or timeout
	that was detected, but then completed before the trigger routine
	completed could result in mangling of the reporting thread's
	file position pointer.
-	Fixed problem with writing I/O trigger when -o switch is used.
-	Fixed sample output display jitter.
-	Fixed data corruption in verification mode with random patterns
	(-l35 and -l47).
-	-x/-X now adds a default base offset when no argument is given.
-	Fix for -l1, -l2, -l4 patterns not working with -X when -y is specified.
-	Excluding -l46 from running with -X to prevent false data corruption.

Catapult 1.3.1
-	Fixed problem with -w switch not calling process exits on the
	UNIX platforms.
-	Fixed problem with argument passing in catapult that would cause
	Pain/maim to not get the correct arguments (Linux/Solaris).
-	Fixed directory naming for multitarget tests on Linux.
-	Linux -v options now lists files it is reading.
-	-n option now names file(s) to be deleted.
-	Prevents auto-inclusion of boot and OS-install devices or volume group
	member devices in the presence of LVM1 or LVM2.
-	Fixed vlog.log not listing all tests.
-	Fixed verification mode reporting incorrect test failures.
-	Fixed "catapult -p" creating directories.


GUI 1.1
-	Removed trace debugging information.  Added option to turn it on.
-	Added Override option to allow running to drives with no drive
	signature.
-	Added option to enable/disable trace logging.
-	Added Stop On Error option to allow the user to shut down all tests
	after a set amount of time when an error is detected.

========================================================================
Notes regarding Windows setup program for 1.2.
========================================================================

** IMPORTANT UPDATE NOTE FOR WINDOWS VERSION
-	If updating from a previous release, please be sure to first
	choose the "Remove" option from the setup program to remove
	the old installation.  Run the setup program again to install
	the updated versions.
-	Choose the same installation directory as the previous install
	to pick up the existing configuration information.

** WINDOWS XP SP2+ AND DATA EXECUTION PREVENTION

	When running the installation on Windows XP with Service Pack 2
	or higher, the Data Execution Prevention security measure may
	present a dialog box informing that it has shutdown the
	Windows Installer.  When this happens:

	-	Ignore the warning message but DO NOT CLOSE the
		Data Execution Prevention dialog box.
	-	Continue and complete the installation process.
	-	Close the Data Execution Prevention dialog box.

=======================================================================
Medusa Labs Test Tools Suite 1.2
=======================================================================
Test Tools Updates
-	pain and maim updated to 2.14
-	catapult updated to 1.3
-	Introduction of GUI (1.0) on Windows platforms.

Installer Changes
-	Updated SafeNet dongle driver for license server.
-	Xgig Trigger template samples are installed with with Windows setup.

Pain/Maim 2.14
-	Added patterns #34, 50-53
-	Added SAS/SATA data pattern scrambling (-j and -J switches)
-	Changed I/O monitoring behavior (-M).  Now on by default, with
	full I/O halts and individual I/O timeouts reported after I/Os
	are pending for more than the specified performance sample time.
	Monitor time can be modified in seconds (ex. -M60 equals 60
	seconds) or disabled altogether (-M0 disables monitoring.)

Pain 2.14
-	Fixed sector I/O test (-s).  It was incorrectly running to
	segments of default buffer size, rather than sector size.

Maim 2.14
-	Added millisecond resolution to Maim burst mode (-g).  Using
	numeric values alone equals seconds (ex. -g3 for 3 seconds
	between bursts.)  Adding 'm' to to number specifies millisecond
	resolution (-g100m equals 100 milliseconds.)

Catapult 1.3
-	Multi-target no longer creates directories based on pids.
-	The -vp option now only halts when errors are found and will
	only report success if -vq is not specified.
-	Added -g option to allow the user to specify a prefix for the
	generated files and directories instead of the default system
	name.
-	On Linux, running the -t option without running a test will
	create the raw links, so if you run a multi-target test from a
	remote shell, the raw links referenced in the targets.dat will
	be valid.

=======================================================================
Medusa Labs Test Tools Suite 1.1, Update 1, February 24, 2005
=======================================================================
Test Tools Updates
-	pain and maim updated to 2.13.1
-	catapult updated to 1.2.1

Installer Changes
-	Fix for intermitent license server USB driver install failures

Pain/Maim 2.13.1
-	Fix for license validation failure in Terminal Server sessions

Catapult 1.2.1
-	Fix for buffer overrun issue in command line parser
-	Fixed false positive evaluations of test verification

=======================================================================
Medusa Labs Test Tools Suite 1.1, January 20, 2005
=======================================================================
Test Tools Updates
-	pain and maim updated to 2.13
-	catapult updated to 1.2

Installer Changes
-	Removal of Agilis license components
-	Addition of SafeNet license components
-	No longer require Domain field for licensing configuration

Pain/Maim 2.13
-	New licensing component to replace Agilis
-	Multi-target support in single process

Maim 2.13
-	Initial public release of Maim for Solaris and Linux* (POSIX
	real time aio)

Catapult 1.2
-	Enabled -t option to allow for multi-target option in Pain/Maim.
-	Catapult no longer will allow running to removable media with
	no media present.
-	Catapult on Linux now checks that the tool you try to run exists.
-	Cleanups now remove more files.
-	File system mis-ordering error fixed.

* Linux kernel 2.6 and higher support only.


=======================================================================
Medusa Labs Test Tools Suite 1.0 Update 1, August 25, 2004
=======================================================================

Test Tools Updates
-	pain updated to 2.12
-	maim (Windows only) updated to 2.12
-	catapult updated to 1.1
-	Please check for appropriate versions after installation if
	upgrading from an older version.

Installer Changes
-	For both Windows and UNIX versions, the License Manager
	configuration page no longer asks for "Customer" name.

Pain/Maim 2.12
-	Support for Agilis 1.0.03 license server.
-	Additional debug output for license issues.
-	Minor command line tweaks.

Catapult 1.1
-	Added new post processing that uses existing .csv files instead
	of the .prf.
-	Minor fixes to command line parsing.
-	Fixed major bug with drives containing no drive signature.
-	Fixed a memory leak that would cause Windows to complain on
	restarting even if Catapult did not crash.
-	Fixed a problem in windows whereby some usb drives without
	signatures were not being run to.
-	Fixed the "No to all" option in Windows.
-	Drives without signatures are now listed in the drive listing
	(Windows).
-	Drive detection changed in Solaris, should be more reliable now.

=======================================================================
Medusa Labs Test Tool Suite 1.0pr2, June 2004
=======================================================================

General
-	Added installers for Windows, Linux, and Solaris.

Test Tool Proxy Daemon 1.0
-	New addition.
-	Currently provides synchronization among multiple processes of
	test tools with additional features planned for future releases.
-	Required to be running for the test tools to function correctly.
	Starts up automatically as a Windows Service or UNIX daemon.

Catapult 1.0 
-	Added Linux and Solaris support.

Pain/Maim 2.11
-	Now using system host name when WS_NAME environment variable
	is not present.
-	Fixed some inaccurate program return codes.
-	Now creating CSV (comma separated value) performance log by
	default.  Error counters have been added.  
-	Revised I/O signatures to be consistent in all tools.  
-	Now using static linking to all required libraries on all
	operating systems.
-	License server details are now stored in a configuration file,
	created during installation.
-	Uses the proxy daemon for synchronizing license check.
-	Fixed problem with handling long host names.
-	Added I/O burst mode (-g option in Maim only.)
-	Added SMB optimized mode (-m20 in Pain.)  This MAY increase
	performance when running to some SMB servers.
-	Minor log file corrections and additions.

-----------------------------------------------------------------------

